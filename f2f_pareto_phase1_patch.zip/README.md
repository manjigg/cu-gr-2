# F2F HBT Pareto Phase 1 patch

Base branch: `two-3d-change-from-2d-baseline`  
Base commit: `f511883acccf9dfe6e22cde6e79f33a470a01689`

## Included changes

1. Removes the `max_hbt` argument from the HBT-count DP API.
2. Derives the DP HBT-count upper bound from the projected tree:
   one possible crossing per tree edge plus the maximum local mismatch
   contribution at each projected node.
3. Adds a per-net Pareto archive over wirelength, HBT count, via count,
   incremental wire overflow, incremental resource overflow and congestion cost.
4. Checks connectivity before inserting a candidate into the Pareto archive.
5. Preserves the incumbent route in the archive when a later reroute stage runs.
6. Writes per-net Pareto candidates to a TSV file when `pareto_output` is set.

## Important scope limitation

This is **per-net Pareto candidate generation**, not a global chip-level Pareto
optimizer. The existing `routeJobs()` flow still commits one selected route per
net using its current acceptance policy. A true global Pareto optimizer must
jointly select candidates across nets while accounting for shared Wire/Via
capacity and HBT-site conflicts. This patch deliberately does not claim that
global optimization has been solved.

The existing `max_projection_nodes` guard remains a compute-budget guard. If a
projected tree exceeds it, the existing legacy topology fallback is still used.
`beam_width` and `max_sites` remain candidate-search effort parameters; they are
not HBT-count targets.

## Apply

1. Back up or commit your current working tree.
2. Extract this ZIP into the repository root, preserving `src/` and `tests/`.
   This replaces `F2fCandidateSearch.h/.cpp` and the DP test, and adds
   `F2fPareto.h/.cpp` plus its unit test.
3. Run:

   ```bash
   python3 apply_pareto_phase1.py
   ```

   The script modifies `src/gr/F2fRouter.cpp` and removes the obsolete `max_hbt`
   setting from `tests/h3d/test_candidate_phase1.py`. It validates every expected
   source block before writing either file.
4. `src/CMakeLists.txt` uses `GLOB_RECURSE`, so `F2fPareto.cpp` is automatically
   included on the next CMake configure/build.
5. Add this optional key to your F2F JSON config:

   ```json
   "pareto_output": "f2f_pareto.tsv"
   ```

   Keep this path distinct from all inputs, guides, HBT output and diagnostics.
   The old `candidate_search.max_hbt` key may remain in an old config, but the
   new DP ignores it.

## Standalone tests

```bash
g++ -std=c++14 -O2 tests/h3d/F2fCandidateSearchTest.cpp \
    src/gr/F2fCandidateSearch.cpp -o /tmp/f2f_dp_test
/tmp/f2f_dp_test

g++ -std=c++14 -O2 tests/h3d/F2fParetoTest.cpp \
    src/gr/F2fPareto.cpp -o /tmp/f2f_pareto_test
/tmp/f2f_pareto_test
```

Then rebuild CUGR using your existing build script and first run AES.

## Interpretation

The HBT count is no longer capped by a user-provided `max_hbt`. Its DP search
range is derived from the actual projected-tree structure. The number of
physical HBT sites and site conflicts remain real feasibility constraints.

The TSV contains candidate metrics measured against the resource state at the
time that net is routed. Overflow/congestion deltas are context-dependent and
order-dependent; they are not a final global chip score.
